<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Assemblies extends CI_Controller {

	public function __construct() {
		parent::__construct();
		parent::redirectToLoginPage();
	}

	public function index()	{
		$data = array ();
		$assembliesData = $this->Common_model->getAllTableRows(TBL_ASSEMBLIES);
		$data['assemblies'] = $assembliesData;
		loadViewHelper ( 'assemblies/grid', $data );		
	}
	
	
}