<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common extends CI_Controller {
	
    public function __construct() {
        parent::__construct();
    }
    
    public function updateRecord(){
        $record_id = $this->input->post('id');
        $table = $this->input->post('tbl');
        $make = $this->input->post('make');

        $input = array();
        $inputdata ['is_active'] = 1;
        if($make === "inactive"){
                $inputdata ['is_active'] = 0;
        }
        $inputdata ['modified'] = date("Y-m-d H:i:s");

        if($table === "assembly"){
                $table = TBL_ASSEMBLIES;
        }elseif ($table === "mandal"){
                $table = TBL_MANDALS;
        }elseif ($table === "village"){
                $table = TBL_VILLAGES;
        }elseif ($table === "member"){
                $table = TBL_MEMBERS;
        }elseif ($table === "user"){
                $table = TBL_USER;
        }
        $result = $this->Common_model->updateTableRecord($inputdata,$table,$record_id);
        header ( 'Content-Type: application/json' );
        if($result)
                echo json_encode ( array ('status' => 'success'));
        else
                echo json_encode ( array ('status' => 'fail'));
    }
}