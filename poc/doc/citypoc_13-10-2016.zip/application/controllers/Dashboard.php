<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct() {
		parent::__construct();
		parent::redirectToLoginPage();
	}

	public function index()	{
		$data = array ();
		loadViewHelper ( 'dashboard', $data );		
	}
		
	public function changePassword()	{
		$data = array ();
		loadViewHelper ( 'changepassword', $data );
	}
	
	public function savepassword(){
		$this->load->model('User_model','user_model');
		$this->form_validation->set_rules('password', 'password', 'trim|required');
		$this->form_validation->set_rules('confirmPassword', 'confirmPassword', 'trim|required|matches[password]');
		if ($this->form_validation->run() == FALSE) {
			$data = array ();
			loadViewHelper ( 'changepassword', $data );
		} else {
			$user_id = $this->session->userdata['logged_in']['user_id'];
			$newpassword = $this->input->post('password');
			$data = array(
					'password' => md5($newpassword),
					'date_modified' =>  date("Y-m-d H:i:s"),
			);
			$result = $this->user_model->updateUser($data,$user_id);
			if($result){
				$this->session->set_flashdata('success','Update successfull.');
			}else{
				$this->session->set_flashdata('error','Update Failed.');
			}
			redirect(SITEURL, 'refresh');
		}
	}
}