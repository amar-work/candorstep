<?php 
	
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * This controller contains the franchiselogin, showroomlogin and logout.
 *
 * @filesource : Login
 * @author : Manjunath
 * @version : 1.0.0
 *
 */

class Login extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		// Load database
		$this->load->model('User_model','user_model');
	}
	
	public function index()	{
		if($this->session->userdata('logged_in')){
			redirect(HOME_URL);
		}else{
			$this->load->view('login');
		}
	}
	
	/**
	 * This method is used for User login.
	 *
	 */
	public function userlogin(){
		$this->form_validation->set_rules('user_name', 'user_name', 'trim|required');
		$this->form_validation->set_rules('password', 'password', 'trim|required');
	
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('login');
		} else {
	
			$data = array(
					'user_name' => $this->input->post('user_name'),
					'user_password' => $this->input->post('password')
			);
			$result = $this->user_model->login($data);
			$this->setSessionData($result);
		}
	}
	
	public function setSessionData($result){
		if($result != FALSE){
			$sess_array = array(
					'user_id'   => $result[0]->id,
					'first_name'  => $result[0]->first_name,
					'last_name' => $result[0]->last_name,
					'email'  => $result[0]->emailid,
					'is_active'  => $result[0]->is_active,
					'created'  => $result[0]->created,
			);
			
			// Add user data in session
			$this->session->set_userdata('logged_in',$sess_array);
			redirect(HOME_URL);
		
		}else{
			$data = array(
					'error_message' => 'Invalid Username or Password'
			);
			$this->load->view('login', $data);
		}
	}
	
	// Logout 
	public function logout() {
	
		// Removing session data
		$sess_array = array(
				'username' => ''
		);
		$this->session->unset_userdata('logged_in', $sess_array);
		$data = array(
			'message_display' => 'Successfully Logout'
		);
		$this->load->view('login', $data);
	}
	
}

/* End of file login.php */
/* Location: ./application/controllers/login.php */