<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mandals extends CI_Controller {

	public function __construct() {
		parent::__construct();
		parent::redirectToLoginPage();
		$this->load->model('Mandals_model', 'Mandals_model');
	}

	public function index()	{
		$data = array ();
		$mandalsData = $this->Mandals_model->getAllMandals();
		$data['mandals'] = $mandalsData;
		loadViewHelper ( 'mandals/grid', $data );		
	}
	
	public function addoreditmandal() {
		$id = "";
		$resultArr = array();
		if($this->input->get('id')){
			$id = $this->input->get('id');
			$resultArr = $this->Mandals_model->getMandalDetails($id);
			//print_r($resultArr);
		}
		$assembliesArr = $this->Common_model->getAllTableRows(TBL_ASSEMBLIES);
		$data['assemblies'] = $assembliesArr;
		$data['mandal'] = $resultArr;
		loadViewHelper('mandals/addoredit', $data);
	}
	
	public function saveorupdatemandal() {
		$id = "";
		if($this->input->post('mandal_id')){
			$id =  $this->input->post('mandal_id');
		}
		$this->form_validation->set_rules ( 'mandal_name', 'Mandal Name', 'trim|required' );
		$this->form_validation->set_rules ( 'assembly_id', 'Assembly Name', 'trim|required' );
		$assembly_id = $this->input->post('assembly_id');
		$result = "";
		if ($this->form_validation->run () == FALSE) {
			$this->session->set_flashdata('error', validation_errors());
			redirect(MANDAL_ADD_OR_EDIT_URL."?id=".$id);
		} else {
			$inputData = array(
					'mandal_name' => $this->input->post('mandal_name'),
					'assembly_id' => $assembly_id,
					'modified' => date ( "Y-m-d H:i:s" )
			);
			if($id != ""){
				$result = $this->Common_model->updateTableRecord ($inputData,TBL_MANDALS,$id );
			}else{
				$result = $this->Common_model->saveTableRecord($inputData,TBL_MANDALS);
			}
			if($result){
				$this->session->set_flashdata('success','Save or Update Successfull.');
			}else{
				$this->session->set_flashdata('error','Save or Update Failed.');
			}
			redirect(MANDALS_URL);
		}
	
	}
	
	
}