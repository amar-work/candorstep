<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Members extends CI_Controller {

	public function __construct() {
		parent::__construct();
		parent::redirectToLoginPage();
		$this->load->model('Members_model', 'Members_model');
	}

	public function index()	{
		$data = array ();
		$membersData = $this->Members_model->getAllMembers();
		$data['members'] = $membersData;
		loadViewHelper ( 'members/grid', $data );		
	}
	
	public function addoreditmember() {
		$id = "";
		$resultArr = array();
		if($this->input->get('id')){
			$id = $this->input->get('id');
			$resultArr = $this->Members_model->getMemberDetails($id);
			#print_r($resultArr);
		}
		$assembliesArr = $this->Common_model->getAllTableRows(TBL_ASSEMBLIES,1);
		$mandalsArr = $this->Common_model->getAllTableRows(TBL_MANDALS,1);
		$villagessArr = $this->Common_model->getAllTableRows(TBL_VILLAGES,1);
		$data['assemblies'] = $assembliesArr;
		$data['mandals'] = $mandalsArr;
		$data['villages'] = $villagessArr;
		$data['member'] = $resultArr;
		loadViewHelper('members/addoredit', $data);
	}
	
	public function saveorupdatemember() {
		$id = "";
		if($this->input->post('member_id')){
			$id =  $this->input->post('member_id');
		}
		$this->form_validation->set_rules ( 'member_name', 'Member Name', 'trim|required' );
		$this->form_validation->set_rules ( 'assembly_id', 'Assembly Name', 'trim|required' );
		$this->form_validation->set_rules ( 'mandal_id', 'Mandal Name', 'trim|required' );
		$this->form_validation->set_rules ( 'village_id', 'Village Name', 'trim|required' );
		$assembly_id = $this->input->post('assembly_id');
		$mandal_id =  $this->input->post('mandal_id');
		$village_id =  $this->input->post('village_id');
		$result = "";
		if ($this->form_validation->run () == FALSE) {
			$this->session->set_flashdata('error', validation_errors());
			redirect(MEMBER_ADD_OR_EDIT_URL."?id=".$id);
		} else {
			
			$inputData = array(
					'member_name' => $this->input->post('member_name'),
					'assembly_id' => $assembly_id,
					'mandal_id' => $mandal_id,
					'village_id' => $village_id,
					'modified' => date ( "Y-m-d H:i:s" )
			);
			if($this->input->post('ward_number')){
				$inputData['ward_number'] = $this->input->post('ward_number');
			}
			if($this->input->post('occupation')){
				$inputData['occupation'] = $this->input->post('occupation');
			}
			if($this->input->post('phone_number')){
				$inputData['phone_number'] = $this->input->post('phone_number');
			}
			if($_FILES['member_image']['name'] != ""){
				$inputData['member_image'] = uploadFiles($_FILES['member_image']);
			}
			if($id != ""){
				$result = $this->Common_model->updateTableRecord ($inputData,TBL_MEMBERS,$id );
			}else{
				$result = $this->Common_model->saveTableRecord($inputData,TBL_MEMBERS);
			}
			if($result){
				$this->session->set_flashdata('success','Save or Update Successfull.');
			}else{
				$this->session->set_flashdata('error','Save or Update Failed.');
			}
			redirect(MEMBERS_URL);
		}
	
	}
}