<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the adsoncaar application
 * 
 * @category	Restful WebService
 * @controller  Services Controller
 * @author		Manju
 */

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH.'/libraries/REST_Controller.php';

class Services extends REST_Controller{
	
	public function __construct() {
		parent::__construct();
	}
	
	
	/**
	 * This service is used to get all the cities for a particulat state.
	 * 
	 * @serviceType GET
	 * @param string state
	 * @responseType JSON
	 */
	function sample_get(){
		$message = array(
				'status' => 1,
				'result' => "Sample Web Service"
		);
		$this->response($message, 200); // 200 being the HTTP response code
	}
	

	
	/**
	 * Common method to send error response.
	 */
	public function sendErrorResponse($message,$reason){
		$error_message = array(
				'status' => 0,
				'reason'=> $reason,
				'message' => $message
		);
		$this->response($error_message, 200);
	}
}
