<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct() {
		parent::__construct();
		parent::redirectToLoginPage();
		$this->load->model('User_model', 'User_model');
	}

	public function index()	{
		$data = array ();
		$usersData = $this->Common_model->getAllTableRows(TBL_USER);
		$data['users'] = $usersData;
		loadViewHelper ( 'users/grid', $data );		
	}
	
	public function addoredituser() {
		$id = "";
		$resultArr = array();
		if($this->input->get('id')){
			$id = $this->input->get('id');
			$resultArr = $this->User_model->getUserDetails($id);
		}
		$data['user'] = $resultArr;
		loadViewHelper('users/addoredit', $data);
	}
	
	public function saveorupdateuser() {
		$id = "";
		if($this->input->post('user_id')){
			$id =  $this->input->post('user_id');
		}
		$this->form_validation->set_rules ( 'first_name', 'First Name', 'trim|required' );
		$this->form_validation->set_rules ( 'last_name', 'Last Name', 'trim|required' );
		$this->form_validation->set_rules ( 'emailid', 'Email Id', 'trim|required' );
		$this->form_validation->set_rules ( 'txt_password', 'Password', 'trim|required' );
		$result = "";
		if ($this->form_validation->run () == FALSE) {
			$this->session->set_flashdata('error', validation_errors());
			redirect(USER_ADD_OR_EDIT_URL."?id=".$id);
		} else {
			$inputData = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'emailid' => $this->input->post('emailid'),
					'modified' => date ( "Y-m-d H:i:s" )
			);
			if($this->input->post('txt_password')){
				$password = $this->input->post('txt_password');
				$inputData['txt_password'] = $password;
				$inputData['user_password'] = MD5($password);
			}
			if($id != ""){
				$result = $this->Common_model->updateTableRecord ($inputData,TBL_USER,$id );
			}else{
				$result = $this->Common_model->saveTableRecord($inputData,TBL_USER);
			}
			if($result){
				$this->session->set_flashdata('success','Save or Update Successfull.');
			}else{
				$this->session->set_flashdata('error','Save or Update Failed.');
			}
			redirect(USERS_URL);
		}
	
	}
	
	
}