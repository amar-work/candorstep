<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Villages extends CI_Controller {

	public function __construct() {
		parent::__construct();
		parent::redirectToLoginPage();
		$this->load->model('Villages_model', 'Villages_model');
	}

	public function index()	{
		$data = array ();
		$villagesData = $this->Villages_model->getAllVillages();
		$data['villages'] = $villagesData;
		loadViewHelper ( 'villages/grid', $data );		
	}
	
	public function addoreditvillage() {
		$id = "";
		$resultArr = array();
		if($this->input->get('id')){
			$id = $this->input->get('id');
			$resultArr = $this->Villages_model->getVillageDetails($id);
			#print_r($resultArr);
		}
		$assembliesArr = $this->Common_model->getAllTableRows(TBL_ASSEMBLIES,1);
		$mandalsArr = $this->Common_model->getAllTableRows(TBL_MANDALS,1);
		$data['assemblies'] = $assembliesArr;
		$data['mandals'] = $mandalsArr;
		$data['village'] = $resultArr;
		loadViewHelper('villages/addoredit', $data);
	}
	
	public function saveorupdatevillage() {
		$id = "";
		if($this->input->post('village_id')){
			$id =  $this->input->post('village_id');
		}
		$this->form_validation->set_rules ( 'village_name', 'Village Name', 'trim|required' );
		$this->form_validation->set_rules ( 'assembly_id', 'Assembly Name', 'trim|required' );
		$this->form_validation->set_rules ( 'mandal_id', 'Mandal Name', 'trim|required' );
		$assembly_id = $this->input->post('assembly_id');
		$mandal_id =  $this->input->post('mandal_id');
		
		$result = "";
		if ($this->form_validation->run () == FALSE) {
			$this->session->set_flashdata('error', validation_errors());
			redirect(VILLAGE_ADD_OR_EDIT_URL."?id=".$id);
		} else {
			$inputData = array(
					'village_name' => $this->input->post('village_name'),
					'assembly_id' => $assembly_id,
					'mandal_id' => $mandal_id,
					'modified' => date ( "Y-m-d H:i:s" )
			);
			if($id != ""){
				$result = $this->Common_model->updateTableRecord ($inputData,TBL_VILLAGES,$id );
			}else{
				$result = $this->Common_model->saveTableRecord($inputData,TBL_VILLAGES);
			}
			if($result){
				$this->session->set_flashdata('success','Save or Update Successfull.');
			}else{
				$this->session->set_flashdata('error','Save or Update Failed.');
			}
			redirect(VILLAGES_URL);
		}
	
	}
	
}