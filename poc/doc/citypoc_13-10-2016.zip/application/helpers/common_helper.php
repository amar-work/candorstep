<?php

if (! defined ( 'BASEPATH' ))	exit ( 'No direct script access allowed' );


if (! function_exists ( 'loadViewHelper' )) {
	function loadViewHelper($filepath, $data) {
		$CI = & get_instance ();
		$CI->load->view ( 'common/header' );
		$CI->load->view ( $filepath, $data );
		$CI->load->view ( 'common/footer' );
	}
}

if(!function_exists('getCurrentTime')){
	function getCurrentTime(){
		$timeparts = explode(" ",microtime());
		$currenttime = bcadd(($timeparts[0]*1000),bcmul($timeparts[1],1000));
		return $currenttime;
	}
}

/**
 * Helper method to uploadFiles files
 */
if (! function_exists ( 'uploadFiles' )) {
	function uploadFiles($file) {
		$CI = & get_instance ();
		//$milliseconds = round ( microtime ( true ) * 1000 );
		$milliseconds = getCurrentTime();
		$ext = pathinfo ( $file['name'], PATHINFO_EXTENSION );
		$new_file_name = $milliseconds . "." . $ext;
		$CI->load->library ( 'upload' );
		$config ['allowed_types'] = 'jpg|jpeg';
		$config ['upload_path'] = PROFILE_IMAGE_PATH;
		$config ['file_name'] = $new_file_name;
		//print_r($config);
		$_FILES ['file'] ['name'] = $file ['name'];
		$_FILES ['file'] ['type'] = $file ['type'];
		$_FILES ['file'] ['tmp_name'] = $file ['tmp_name'];
		$_FILES ['file'] ['error'] = $file ['error'];
		$_FILES ['file'] ['size'] = $file ['size'];
		$CI->upload->initialize ( $config );
		if ($CI->upload->do_upload ( 'file' )) {
			//do_resize($new_file_name,$config ['upload_path']);
			return $new_file_name;
		}else{
			return false;
		}
	}
}

if (! function_exists ( 'is_image' )) {
	function is_image($path)
	{
		try {
			$ext = pathinfo($path, PATHINFO_EXTENSION);
			if($ext){
				$a = getimagesize($path);
				$image_type = $a[2];
				if(in_array($image_type , array(IMAGETYPE_GIF , IMAGETYPE_JPEG ,IMAGETYPE_PNG , IMAGETYPE_BMP)))
				{
					return true;
				}
			}
			if($ext == 'pdf'){
				return true;
			}
			return false;
		} catch (Exception $e) {
			return false;
		}
	}
}
