<?php
/**
 * This class contains the information about User actions performed in the application
 *
 *
 *
 * @copyright
 * @license
 * @version
 * @link
 * @since
 */
class Assemblies_model extends CI_Model  {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }

   
}

?>