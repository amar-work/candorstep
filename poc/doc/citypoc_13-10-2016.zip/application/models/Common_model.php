<?php
/**
 * This class contains the information about User actions performed in the application
 *
 *
 *
 * @copyright
 * @license
 * @version
 * @link
 * @since
 */
class Common_model extends CI_Model  {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }

    public function getAllTableRows($table, $flag=""){
    	$this->db->select('*');
    	$this->db->from($table);
    	if($flag != ""){
    		$this->db->where('is_active = 1');
    	}
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result;
    	}else{
    		return array();
    	}
    }
    
    public function saveTableRecord($inputdata,$table) {
        $this->db->insert($table, $inputdata);
        return ($this->db->insert_id() > 0) ? $this->db->insert_id() : FALSE;
    }

    public function updateTableRecord($inputdata,$table,$record_id){
        $this->db->where('id', $record_id);
        $this->db->update($table, $inputdata);
        return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
    }
	
}

?>