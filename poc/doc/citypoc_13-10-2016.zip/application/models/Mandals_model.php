<?php
/**
 * This class contains the information about User actions performed in the application
 *
 *
 *
 * @copyright
 * @license
 * @version
 * @link
 * @since
 */
class Mandals_model extends CI_Model  {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }

   
    function getAllMandals(){
    	$this->db->select('m.mandal_name,m.is_active, a.assembly_name, m.id as mandal_id, a.id as assembly_id, DATE(m.created) as created_date');
    	$this->db->from(TBL_MANDALS.' m');
    	$this->db->join(TBL_ASSEMBLIES.' a', 'a.id = m.assembly_id');
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result;
    	}else{
    		return array();
    	}
    }
    
    function getMandalDetails($id){
    	$this->db->select('m.id as mandal_id, m.mandal_name, m.is_active, a.id as assembly_id, a.assembly_name, DATE(m.created) as created_date');
    	$this->db->from(TBL_MANDALS.' m');
    	$this->db->join(TBL_ASSEMBLIES.' a', 'a.id = m.assembly_id');
    	$this->db->where('m.id',$id);
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result[0];
    	}else{
    		return array();
    	}
    }
}

?>