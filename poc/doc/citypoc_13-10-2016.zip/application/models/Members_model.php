<?php
/**
 * This class contains the information about User actions performed in the application
 *
 *
 *
 * @copyright
 * @license
 * @version
 * @link
 * @since
 */
class Members_model extends CI_Model  {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }

    function getAllMembers(){
    	$this->db->select('me.id as member_id, me.member_name, me.member_image, me.mandal_id, me.assembly_id, 
    			me.phone_number, me.ward_number, me.occupation,
    			me.village_id, me.is_active, v.village_name, m.mandal_name, a.assembly_name, DATE(m.created) as created_date');
    	$this->db->from(TBL_MEMBERS.' me');
    	$this->db->join(TBL_VILLAGES.' v', 'v.id = me.village_id');
    	$this->db->join(TBL_MANDALS.' m', 'm.id = me.mandal_id');
    	$this->db->join(TBL_ASSEMBLIES.' a', 'a.id = me.assembly_id');
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result;
    	}else{
    		return array();
    	}
    }
    
    function getMemberDetails($id){
    	$this->db->select('me.id as member_id, me.member_name, me.member_image, me.mandal_id, me.assembly_id,
				me.phone_number, me.ward_number, me.occupation,
    			me.village_id, v.village_name, m.mandal_name, a.assembly_name, DATE(m.created) as created_date');
    	$this->db->from(TBL_MEMBERS.' me');
    	$this->db->join(TBL_VILLAGES.' v', 'v.id = me.village_id');
    	$this->db->join(TBL_MANDALS.' m', 'm.id = me.mandal_id');
    	$this->db->join(TBL_ASSEMBLIES.' a', 'a.id = me.assembly_id');
    	$this->db->where('me.id',$id);
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result[0];
    	}else{
    		return array();
    	}
    }

}

?>