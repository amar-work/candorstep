<?php
/**
 * This class contains the information about User actions performed in the application
 *
 *
 *
 * @copyright
 * @license
 * @version
 * @link
 * @since
 */
class User_model extends CI_Model  {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }


    // Read data using username and password
    public function login($data) {

        $this -> db -> select("u.id, u.emailid, u.user_password, u.first_name, u.last_name, u.is_active, u.txt_password, u.created");
        $this -> db -> from(TBL_USER." u");
        $this -> db -> where('u.emailid', $data['user_name']);
        $this -> db -> where('u.user_password', MD5($data['user_password']));
        $this -> db -> where('u.is_active', 1);
        $this -> db -> limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
        	return $query->result();
        } else {
        	return false;
        }
    }
    
    
    public function getUserDetails($id){
    	$this -> db -> select("u.id, u.emailid, u.user_password, u.first_name, u.last_name, u.is_active, u.txt_password, u.created");
    	$this -> db -> from(TBL_USER." u");
    	$this -> db -> where('id',$id);
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result[0];
    	}else{
    		return array();
    	}
    }

  	
}

?>