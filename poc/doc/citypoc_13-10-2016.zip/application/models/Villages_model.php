<?php
/**
 * This class contains the information about User actions performed in the application
 *
 *
 *
 * @copyright
 * @license
 * @version
 * @link
 * @since
 */
class Villages_model extends CI_Model  {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }
    
    function getAllVillages(){
    	$this->db->select('v.id as village_id, v.village_name, v.is_active, m.mandal_name, a.assembly_name, m.id as mandal_id, a.id as assembly_id, DATE(m.created) as created_date');
    	$this->db->from(TBL_VILLAGES.' v');
    	$this->db->join(TBL_MANDALS.' m', 'm.id = v.mandal_id');
    	$this->db->join(TBL_ASSEMBLIES.' a', 'a.id = v.assembly_id');
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result;
    	}else{
    		return array();
    	}
    }
    
    function getVillageDetails($id){
    	$this->db->select('v.id as village_id, v.village_name, v.is_active, m.mandal_name, a.assembly_name, m.id as mandal_id, a.id as assembly_id, DATE(m.created) as created_date');
    	$this->db->from(TBL_VILLAGES.' v');
    	$this->db->join(TBL_MANDALS.' m', 'm.id = v.mandal_id');
    	$this->db->join(TBL_ASSEMBLIES.' a', 'a.id = v.assembly_id');
    	$this->db->where('v.id',$id);
    	$query = $this->db->get();
    	$result = $query->result_array();
    	if (sizeof($result) > 0) {
    		return $result[0];
    	}else{
    		return array();
    	}
    }
}

?>