<div class="row">
    <div class="col-md-12">
        <button style="margin-bottom:5px;" onclick=""
                class="btn btn-sm btn-success pull-right" id="AddButton">Add Assembly</button>
    </div>
</div>
<div class="row"></div>
<div class="row">
    <div class="col-md-12">
        <table id="assembliesTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Assembly Name</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>	
            <tbody>
                <?php
                if (sizeof($assemblies) > 0) {
                    foreach ($assemblies as $tempdata) {
                        ?>
                        <tr>
                            <td><?php echo $tempdata['assembly_name']; ?></td>
                            <td class="center">
                                <?php if ($tempdata['is_active'] == 1) { ?>
                                    <span class="label label-success" style="cursor: pointer;"
                                          onclick="commonObj.ajaxCall(data = {'url': '<?php echo COMMONS_UPDATE_URL; ?>',
                                                      'data': 'make=inactive&tbl=assembly&id=' +<?php echo $tempdata['id']; ?>,
                                                      'type': 'POST',
                                                      'redirect': '<?php echo ASSEMBLY_URL; ?>'})">Active</span>
                                      <?php } else { ?>
                                    <span class="label label-warning" style="cursor: pointer;"
                                          onclick="commonObj.ajaxCall(data = {'url': '<?php echo COMMONS_UPDATE_URL; ?>',
                                                      'data': 'make=active&tbl=assembly&id=' +<?php echo $tempdata['id']; ?>,
                                                      'type': 'POST',
                                                      'redirect': '<?php echo ASSEMBLY_URL; ?>'})">InActive</span>
                                      <?php } ?>
                            </td>
                            <td class="center"><a class="label label-info" id="EditButton">Edit</a>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
        </table>
        <div>
        </div>

<script type="text/javascript">
    function editDepartment(department_id, department) {
        $("#department_id").val(department_id);
        $("#department").val(department);
        $("#saveorupdatedepartment").slideToggle("slow");
    }
    $(function () {
        $('#assembliesTable').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });

</script>