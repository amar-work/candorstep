<div class="box box-primary">
	<!-- form start -->
	<div class="col-md-12">
		<?php
			echo "<div class='alert alert-danger'>";
			if (isset ( $error_message )) {
				echo $error_message;
			}
			echo validation_errors ();
			echo "</div>";
		?>
	</div>
	<form method="post" name="changePasswordForm" action="<?php echo SAVE_PASSWORD_URL;?>" id="changePasswordForm">
		 <?php
				/*echo "<div class='alert alert-danger'>";
				if (isset ( $error_message )) {
					echo $error_message;
				}
				echo validation_errors ();
				echo "</div>";*/
		  ?>
		<div class="box-body">
			<div class="form-group">
				<label for="password">New Password</label>
				<input type="password"  class="form-control" id="password" name="password" class="form-control" placeholder="Enter new password">
			</div>
			<div class="form-group">
				<label for="confirmPassword">Confirm New Password</label>
				<input type="password" class="form-control" id="confirmPassword" name="confirmPassword" class="form-control" placeholder="Confirm new password">
			</div>
		</div><!-- /.box-body -->

		<div class="box-footer">
			<button type="submit" class="btn btn-primary">Submit</button>
			<a href="<?php echo HOME_URL; ?>">Cancel</a>
		</div>
	</form>
</div><!-- /.box -->