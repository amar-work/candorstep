<?php 
 	$controller =  $this->router->fetch_class(); 
 	$action =  $this->router->fetch_method();
 	
 	$controllerArr = array(
        	"dashboard" => "Dashboard",	
 			"members" => "Members",
 			"assemblies" => "Assemblies",
 			"mandals" => "Mandals",
 			"villages" => "Villages",
 			"users" => "Users",
 	);
 ?>
<?php if($controller == "dashboard" && $action == "changePassword" ) { ?>
	<h1>Change Password</h1>
<?php } else { ?>
	<h1><?php  echo $controllerArr[$controller]; ?></h1>
<?php } ?>
<ol class="breadcrumb">
	<li><a href="<?php echo HOME_URL;?>"><i class="fa fa-dashboard"></i> Home</a></li>
	<?php if ($controller == "dashboard"   && $action == "index" ) {?>
		<li class="active" ><a href="<?php echo HOME_URL;?>">Dashboard</a></li>
	<?php } else { ?>
		<li class="active" ><a href="javascript:void(0)"><?php  echo $controllerArr[$controller]; ?></a></li>
	<?php } ?>
</ul>