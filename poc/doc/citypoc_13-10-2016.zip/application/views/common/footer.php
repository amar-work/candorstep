                    </section>
                </aside>
        </div><!-- ./wrapper -->
        <script src="<?php echo ASSETS_PATH;?>js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS_PATH;?>js/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Sparkline -->
        <script src="<?php echo BOOTSTRAP_PATH;?>js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo BOOTSTRAP_PATH;?>js/AdminLTE/app.js" type="text/javascript"></script>
		
        <script type="text/javascript" src="<?php echo ASSETS_PATH;?>js/tableTools/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="<?php echo ASSETS_PATH;?>js/tableTools/dataTables.bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo ASSETS_PATH;?>js/tableTools/dataTables.tableTools.js"></script>

        <!-- Include Date Range Picker -->
        <script type="text/javascript" src="<?php echo ASSETS_PATH;?>js/daterangepicker/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo ASSETS_PATH;?>js/daterangepicker/daterangepicker.js"></script>
		
    </body>
</html>