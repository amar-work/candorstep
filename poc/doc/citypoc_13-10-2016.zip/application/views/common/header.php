<html lang="en">
<head>
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title><?php echo PROJECT_TITLE;?></title>
	       
	<!-- start: Mobile Specific -->
	<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	<link href="<?php echo ASSETS_PATH;?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo ASSETS_PATH;?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<!-- Theme style -->
	<link href="<?php echo BOOTSTRAP_PATH;?>css/AdminLTE.css" rel="stylesheet" type="text/css" />
	 <!-- Ionicons -->
    <link href="<?php echo ASSETS_PATH;?>css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="<?php echo BOOTSTRAP_PATH;?>css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="<?php echo BOOTSTRAP_PATH;?>css/AdminLTE.css" rel="stylesheet" type="text/css" />
    
    <link href="<?php echo ASSETS_PATH;?>css/dropify.min.css" rel="stylesheet" type="text/css" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->
	<link rel="stylesheet"  href="<?php echo ASSETS_PATH;?>js/tableTools/dataTables.bootstrap.css">
	<link rel="stylesheet"  href="<?php echo ASSETS_PATH;?>js/tableTools/dataTables.tableTools.css">
	<link rel="stylesheet" type="text/css" href="<?php echo ASSETS_PATH;?>js/daterangepicker/daterangepicker.css" />

	<script src="<?php echo ASSETS_PATH;?>js/jquery.min.js" type="text/javascript"></script>
	<script type="text/javascript">
		var baseURL = "<?php echo SITEURL; ?>";
	</script>
	<script src="<?php echo ASSETS_PATH;?>js/citypoc.js" type="text/javascript"></script>
	<script src="<?php echo ASSETS_PATH;?>js/dropify.min.js" type="text/javascript"></script>
</head>
<body>
<?php 
 	$controller =  $this->router->fetch_class(); 
 	$action =  $this->router->fetch_method();
 	$username = $this->session->userdata['logged_in']['first_name']." ".$this->session->userdata['logged_in']['last_name'];;
 ?>
<body class="skin-blue">
    
     <!-- header logo: style can be found in header.less -->
        <header class="header">
            <a href="<?php echo HOME_URL;?>" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                <?php echo PROJECT_TITLE;?>
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user"></i>
                                <span><?php echo $username; ?> <i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- User image -->
                                <li class="user-header bg-light-blue">
                                    <img src="<?php echo BOOTSTRAP_PATH;?>img/avatar.png" class="img-circle" alt="User Image" />
                                    <p>
                                       <?php echo $username; ?>
                                    </p>
                                </li>
                                <li class="user-footer">
                                    <div class="pull-left">
                                        <a href="<?php echo CHANGEPASSWORD_URL;?>" class="btn btn-default btn-flat">Change Password</a>
                                    </div>
                                    <div class="pull-right">
                                        <a href="<?php echo LOGOUT_URL;?>" class="btn btn-default btn-flat">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

		<div class="wrapper row-offcanvas row-offcanvas-left">
			<!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                	<!-- sidebar menu: : style can be found in sidebar.less -->
                	 <ul class="sidebar-menu">
                        <li <?php if ($controller == "dashboard") {?> class="active" <?php } ?>>
                            <a href="<?php echo HOME_URL;?>">
                                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                    </ul>
                    <ul class="sidebar-menu">
                        <li <?php if ($controller == "assemblies") {?> class="active" <?php } ?>>
                            <a href="<?php echo ASSEMBLY_URL;?>">
                                <i class="fa fa-briefcase"></i> <span>Assemblies</span>
                            </a>
                        </li>
                    </ul>
                     <ul class="sidebar-menu">
                        <li <?php if ($controller == "mandals") {?> class="active" <?php } ?>>
                            <a href="<?php echo MANDALS_URL;?>">
                                <i class="fa fa-dashboard"></i> <span>Mandals</span>
                            </a>
                        </li>
                    </ul>
                     <ul class="sidebar-menu">
                        <li <?php if ($controller == "villages") {?> class="active" <?php } ?>>
                            <a href="<?php echo VILLAGES_URL;?>">
                                <i class="fa fa-dashboard"></i> <span>Villages</span>
                            </a>
                        </li>
                    </ul>
                     <ul class="sidebar-menu">
                        <li <?php if ($controller == "Members") {?> class="active" <?php } ?>>
                            <a href="<?php echo MEMBERS_URL;?>">
                                <i class="fa fa-users"></i> <span>Members</span>
                            </a>
                        </li>
                    </ul>
                    <ul class="sidebar-menu">
                        <li <?php if ($controller == "Users") {?> class="active" <?php } ?>>
                            <a href="<?php echo USERS_URL;?>">
                                <i class="fa fa-user"></i> <span>Users</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>
	
			 <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <?php $this->load->view('common/breadcrumb');?>
                </section>
                <!-- Main content -->
                <section class="content">
		<?php if (isset($success)) {
		    echo '<p class="alert alert-info">'.$success.'</p>';
		} elseif (isset($error) > 0) {
			echo '<div class="alert alert-danger"><strong>Error: </strong>'.$error.'</div>';
		}?>				
			