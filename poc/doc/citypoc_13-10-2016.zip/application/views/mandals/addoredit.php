<div class="row" id="saveorupdateDepartment">
	<div class="col-md-12">
		<?php
		if ($this->session->flashdata ( 'success' )) {
			echo '<p class="alert alert-info">' . $this->session->flashdata ( 'error' ) . '</p>';
		} elseif ($this->session->flashdata ( 'error' )) {
			echo '<div class="alert alert-danger"><strong>Error: </strong>' . $this->session->flashdata ( 'error' ) . '</div>';
		}
		?>
	</div>
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Add or Edit Mandal</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" name="saveorupdateMandalForm" action="<?php echo SAVE_OR_UPDATE_MANDAL ?>" id="saveorupdateMandalForm">
                <div class="row">
                    <input type="hidden" id="mandal_id" name="mandal_id" class="form-control" 
                           value="<?php echo isset($mandal['mandal_id']) ? $mandal['mandal_id'] : '' ?>" />
                    <div class="box-body">
                    	<div class="form-group col-md-6">
                            <label for="assembly_id">Assembly Name</label>
                            <?php $assembly_id = isset($mandal['assembly_id']) ? $mandal['assembly_id'] : ""; ?>
                            <select class="form-control" id="assembly_id" name="assembly_id">
                                <option value="">Select Assembly</option>
                                <?php 
                                if(sizeof($assemblies) > 0){
                                    foreach ($assemblies as $temp){
                                        $selected = "";
                                        if($assembly_id != "" && $temp['id'] == $assembly_id ){ $selected = "selected"; }				
                                ?>
                                <option <?php echo $selected; ?> value="<?php echo $temp['id']?>"><?php echo $temp['assembly_name']; ?></option>
                                <?php } 
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="mandal_name">Mandal Name</label>
                            <input type="text"  class="form-control" id="mandal_name" 
                                   name="mandal_name" placeholder="Mandal Name" 
                                   value="<?php echo isset($mandal['mandal_name']) ? $mandal['mandal_name'] : '' ?>"/>
                        </div>
                        
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="row text-right" >
                    <div class="col-md-12">
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="button" class="btn btn-default"
                                    onclick="javascript:commonObj.pageRedirect('<?php echo MANDALS_URL; ?>')">Cancel</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
            <!-- /.box -->
    </div>
</div>