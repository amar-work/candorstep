<div class="row">
    <div class="col-md-12">
        <button style="margin-bottom:5px;"
                onclick="javascript:commonObj.pageRedirect('<?php echo MANDAL_ADD_OR_EDIT_URL; ?>')"
                class="btn btn-sm btn-success pull-right" id="AddButton">Add MANDAL</button>
    </div>
</div>
<div class="row"></div>
<div class="row">
    <div class="col-md-12">
        <table id="MandalsTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Mandal name</th>
                    <th>Assembly name</th>
                    <th>Created On</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>	
            <tbody>
                <?php
                if (sizeof($mandals) > 0) {
                    foreach ($mandals as $tempdata) {
                        ?>
                        <tr>
                        	<td><?php echo $tempdata['mandal_name']; ?></td>
                            <td><?php echo $tempdata['assembly_name']; ?></td>
                            <td><?php echo $tempdata['created_date']; ?></td>
                            <td class="center">
                                <?php if ($tempdata['is_active'] == 1) { ?>
                                    <span class="label label-success" style="cursor: pointer;"
                                          onclick="commonObj.ajaxCall(data = {'url': '<?php echo COMMONS_UPDATE_URL; ?>',
                                                      'data': 'make=inactive&tbl=mandal&id=' +<?php echo $tempdata['mandal_id']; ?>,
                                                      'type': 'POST',
                                                      'redirect': '<?php echo MANDALS_URL; ?>'})">Active</span>
                                      <?php } else { ?>
                                    <span class="label label-warning" style="cursor: pointer;"
                                          onclick="commonObj.ajaxCall(data = {'url': '<?php echo COMMONS_UPDATE_URL; ?>',
                                                      'data': 'make=active&tbl=mandal&id=' +<?php echo $tempdata['mandal_id']; ?>,
                                                      'type': 'POST',
                                                      'redirect': '<?php echo MANDALS_URL; ?>'})">InActive</span>
                                      <?php } ?>
                            </td>
                            <td class="center"><a class="label label-info" id="EditButton"
                                    onclick="javascript:commonObj.pageRedirect('<?php echo MANDAL_ADD_OR_EDIT_URL.'?id='.$tempdata['mandal_id']; ?>')"
                                    >Edit</a>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
        </table>
        <div>
        </div>
<script type="text/javascript">
    $(function () {
        $('#MandalsTable').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });

</script>