<div class="row" id="saveorupdateDepartment">
	<div class="col-md-12">
		<?php
		if ($this->session->flashdata ( 'success' )) {
			echo '<p class="alert alert-info">' . $this->session->flashdata ( 'error' ) . '</p>';
		} elseif ($this->session->flashdata ( 'error' )) {
			echo '<div class="alert alert-danger"><strong>Error: </strong>' . $this->session->flashdata ( 'error' ) . '</div>';
		}
		?>
	</div>
    <div class="col-md-12">
        <div class="box box-primary">
        	<div class="box-header">
                <h3 class="box-title">Add or Edit Member</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" name="saveorupdateMemberForm"  enctype="multipart/form-data" 
            	action="<?php echo SAVE_OR_UPDATE_MEMBER ?>" id="saveorupdateMemberForm">
                <div class="row">
                     	
                    <input type="hidden" id="member_id" name="member_id" class="form-control" 
                           value="<?php echo isset($member['member_id']) ? $member['member_id'] : '' ?>" />
                    <div class="box-body">
                       <div class="form-group col-md-6">
                            <label for="assembly_id">Assembly Name</label>
                            <?php $assembly_id = isset($member['assembly_id']) ? $member['assembly_id'] : ""; ?>
                            <select class="form-control" id="assembly_id" name="assembly_id">
                                <option value="">Select Assembly</option>
                                <?php 
                                if(sizeof($assemblies) > 0){
                                    foreach ($assemblies as $temp){
                                        $selected = "";
                                        if($assembly_id != "" && $temp['id'] == $assembly_id ){ $selected = "selected"; }				
                                ?>
                                <option <?php echo $selected; ?> value="<?php echo $temp['id']?>"><?php echo $temp['assembly_name']; ?></option>
                                <?php } 
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="mandal_id">Mandal Name</label>
                            <?php $mandal_id = isset($member['mandal_id']) ? $member['mandal_id'] : ""; ?>
                            <select class="form-control" id="mandal_id" name="mandal_id">
                                <option value="">Select Mandal</option>
                                <?php 
                                if(sizeof($mandals) > 0){
                                    foreach ($mandals as $temp){
                                        $selected = "";
                                        if($mandal_id != "" && $temp['id'] == $mandal_id ){ $selected = "selected"; }				
                                ?>
                                <option <?php echo $selected; ?> value="<?php echo $temp['id']?>"><?php echo $temp['mandal_name']; ?></option>
                                <?php } 
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="village_id">Village Name</label>
                            <?php $village_id = isset($member['village_id']) ? $member['village_id'] : ""; ?>
                            <select class="form-control" id="village_id" name="village_id">
                                <option value="">Select Village</option>
                                <?php 
                                if(sizeof($villages) > 0){
                                    foreach ($villages as $temp){
                                        $selected = "";
                                        if($villages != "" && $temp['id'] == $assembly_id ){ $selected = "selected"; }				
                                ?>
                                <option <?php echo $selected; ?> value="<?php echo $temp['id']?>"><?php echo $temp['village_name']; ?></option>
                                <?php } 
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="member_name">Member Name</label>
                            <input type="text"  class="form-control" id="member_name" 
                                   name="member_name" placeholder="Member Name" 
                                   value="<?php echo isset($member['member_name']) ? $member['member_name'] : '' ?>"/>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="ward_number">Ward Number</label>
                            <input type="text"  class="form-control" id="ward_number" 
                                   name="ward_number" placeholder="Ward Number" 
                                   value="<?php echo isset($member['ward_number']) ? $member['ward_number'] : '' ?>"/>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="occupation">Designation/Occupation</label>
                            <input type="text"  class="form-control" id="occupation" 
                                   name="occupation" placeholder="Designation/Occupation" 
                                   value="<?php echo isset($member['occupation']) ? $member['occupation'] : '' ?>"/>
                        </div>
                        <div class="form-group col-md-6">
							<label for="photograph">Photograph</label> 
							<input type="file" id="member_image" name="member_image" class="dropify"
							value="<?php echo isset($member['member_image']) ? PROFILE_IMAGE_URL.$member['member_image'] : '' ?>" />
							<img alt="Profile Image" src="<?php echo isset($member['member_image']) ? PROFILE_IMAGE_URL.$member['member_image'] : '' ?>">
						</div>
                        <div class="form-group col-md-6">
                            <label for="phone_number">Phone Number</label>
                            <input type="text"  class="form-control" id="phone_number" 
                                   name="phone_number" placeholder="Phone Number" 
                                   value="<?php echo isset($member['phone_number']) ? $member['phone_number'] : '' ?>"/>
                        </div>
                        
						
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="row text-right" >
                    <div class="col-md-12">
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="button" class="btn btn-default"
                                    onclick="javascript:commonObj.pageRedirect('<?php echo MEMBERS_URL; ?>')">Cancel</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
            <!-- /.box -->
    </div>
</div>
<script>
	$(document).ready(function(){
		// Basic
		$('.dropify').dropify();

		// Used events
		var drEvent = $('#input-file-events').dropify();

		drEvent.on('dropify.beforeClear', function(event, element){
			return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
		});

		drEvent.on('dropify.afterClear', function(event, element){
			alert('File deleted');
		});

		drEvent.on('dropify.errors', function(event, element){
			console.log('Has Errors');
		});

		var drDestroy = $('#input-file-to-destroy').dropify();
		drDestroy = drDestroy.data('dropify')
		$('#toggleDropify').on('click', function(e){
			e.preventDefault();
			if (drDestroy.isDropified()) {
				drDestroy.destroy();
			} else {
				drDestroy.init();
			}
		})
	});
</script>