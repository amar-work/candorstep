<div class="row" id="saveorupdateUserForm">
    <div class="col-md-12">
		<?php
		if ($this->session->flashdata ( 'success' )) {
			echo '<p class="alert alert-info">' . $this->session->flashdata ( 'error' ) . '</p>';
		} elseif ($this->session->flashdata ( 'error' )) {
			echo '<div class="alert alert-danger"><strong>Error: </strong>' . $this->session->flashdata ( 'error' ) . '</div>';
		}
		?>
	</div>
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Add or Edit User</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" name="saveorupdateUserForm" action="<?php echo SAVE_OR_UPDATE_USER ?>" id="saveorupdateUserForm">
                <div class="row">
                    <input type="hidden" id="user_id" name="user_id" class="form-control" 
                           value="<?php echo isset($user['id']) ? $user['id'] : '' ?>" />
                    <div class="box-body">
                    	<div class="form-group col-md-6">
                            <label for="first_name">First Name</label>
                            <input type="text"  class="form-control" id="first_name" 
                                   name="first_name" placeholder="First Name" 
                                   value="<?php echo isset($user['first_name']) ? $user['first_name'] : '' ?>"/>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="last_name">Last Name</label>
                            <input type="text"  class="form-control" id="last_name" 
                                   name="last_name" placeholder="Last Name" 
                                   value="<?php echo isset($user['last_name']) ? $user['last_name'] : '' ?>"/>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="emailid">Email Id</label>
                            <input type="text"  class="form-control" id="emailid" 
                                   name="emailid" placeholder="Email Id" 
                                   value="<?php echo isset($user['emailid']) ? $user['emailid'] : '' ?>"/>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="txt_password">Password Text</label>
                            <input type="text"  class="form-control" id="txt_password" 
                                   name="txt_password" placeholder="Password Text" 
                                   value="<?php echo isset($user['txt_password']) ? $user['txt_password'] : '' ?>"/>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="row text-right" >
                    <div class="col-md-12">
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="button" class="btn btn-default"
                                    onclick="javascript:commonObj.pageRedirect('<?php echo USERS_URL; ?>')">Cancel</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
            <!-- /.box -->
    </div>
</div>