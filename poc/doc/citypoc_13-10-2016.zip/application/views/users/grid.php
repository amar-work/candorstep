<div class="row">
    <div class="col-md-12">
        <button style="margin-bottom:5px;"
                onclick="javascript:commonObj.pageRedirect('<?php echo USER_ADD_OR_EDIT_URL; ?>')"
                class="btn btn-sm btn-success pull-right" id="AddButton">Add User</button>
    </div>
</div>
<div class="row"></div>
<div class="row">
    <div class="col-md-12">
        <table id="UsersTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Email-Id</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>	
            <tbody>
                <?php
                if (sizeof($users) > 0) {
                    foreach ($users as $tempdata) {
                        ?>
                        <tr>
                        	<td><?php echo $tempdata['first_name']; ?></td>
                            <td><?php echo $tempdata['last_name']; ?></td>
                            <td><?php echo $tempdata['emailid']; ?></td>
                            <td class="center">
                                <?php if ($tempdata['is_active'] == 1) { ?>
                                    <span class="label label-success" style="cursor: pointer;"
                                          onclick="commonObj.ajaxCall(data = {'url': '<?php echo COMMONS_UPDATE_URL; ?>',
                                                      'data': 'make=inactive&tbl=user&id=' +<?php echo $tempdata['id']; ?>,
                                                      'type': 'POST',
                                                      'redirect': '<?php echo USERS_URL; ?>'})">Active</span>
                                      <?php } else { ?>
                                    <span class="label label-warning" style="cursor: pointer;"
                                          onclick="commonObj.ajaxCall(data = {'url': '<?php echo COMMONS_UPDATE_URL; ?>',
                                                      'data': 'make=active&tbl=user&id=' +<?php echo $tempdata['id']; ?>,
                                                      'type': 'POST',
                                                      'redirect': '<?php echo USERS_URL; ?>'})">InActive</span>
                                      <?php } ?>
                            </td>
                            <td class="center"><a class="label label-info" id="EditButton"
                                    onclick="javascript:commonObj.pageRedirect('<?php echo USER_ADD_OR_EDIT_URL.'?id='.$tempdata['id']; ?>')"
                                    >Edit</a>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
        </table>
        <div>
        </div>
<script type="text/javascript">
    $(function () {
        $('#UsersTable').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });

</script>