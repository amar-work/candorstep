<div class="row" id="saveorupdateDepartment">
	<div class="col-md-12">
		<?php
		if ($this->session->flashdata ( 'success' )) {
			echo '<p class="alert alert-info">' . $this->session->flashdata ( 'error' ) . '</p>';
		} elseif ($this->session->flashdata ( 'error' )) {
			echo '<div class="alert alert-danger"><strong>Error: </strong>' . $this->session->flashdata ( 'error' ) . '</div>';
		}
		?>
	</div>
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Add or Edit Village</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" name="saveorupdateVillageForm" action="<?php echo SAVE_OR_UPDATE_VILLAGE ?>" id="saveorupdateVillageForm">
                <div class="row">
                     <input type="hidden" id="village_id" name="village_id" class="form-control" 
                           value="<?php echo isset($village['village_id']) ? $village['village_id'] : '' ?>" />
                    <div class="box-body">
                       <div class="form-group col-md-6">
                            <label for="assembly_id">Assembly Name</label>
                            <?php $assembly_id = isset($village['assembly_id']) ? $village['assembly_id'] : ""; ?>
                            <select class="form-control" id="assembly_id" name="assembly_id">
                                <option value="">Select Assembly</option>
                                <?php 
                                if(sizeof($assemblies) > 0){
                                    foreach ($assemblies as $temp){
                                        $selected = "";
                                        if($assembly_id != "" && $temp['id'] == $assembly_id ){ $selected = "selected"; }				
                                ?>
                                <option <?php echo $selected; ?> value="<?php echo $temp['id']?>"><?php echo $temp['assembly_name']; ?></option>
                                <?php } 
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="mandal_id">Mandal Name</label>
                            <?php $mandal_id = isset($village['mandal_id']) ? $village['mandal_id'] : ""; ?>
                            <select class="form-control" id="mandal_id" name="mandal_id">
                                <option value="">Select Mandal</option>
                                <?php 
                                if(sizeof($mandals) > 0){
                                    foreach ($mandals as $temp){
                                        $selected = "";
                                        if($mandal_id != "" && $temp['id'] == $mandal_id ){ $selected = "selected"; }				
                                ?>
                                <option <?php echo $selected; ?> value="<?php echo $temp['id']?>"><?php echo $temp['mandal_name']; ?></option>
                                <?php } 
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="mandal_name">Village Name</label>
                            <input type="text"  class="form-control" id="village_name" 
                                   name="village_name" placeholder="Village Name" 
                                   value="<?php echo isset($village['village_name']) ? $village['village_name'] : '' ?>"/>
                        </div>
                        
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="row text-right" >
                    <div class="col-md-12">
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="button" class="btn btn-default"
                                    onclick="javascript:commonObj.pageRedirect('<?php echo VILLAGES_URL; ?>')">Cancel</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
            <!-- /.box -->
    </div>
</div>